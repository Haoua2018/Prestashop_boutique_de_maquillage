<?php

class SearchController extends SearchControllerCore
{
    public function initContent()
    {
        parent::initContent();
        $original_query = $_GET['search_query'];
        $DB = db::getInstance();

        $query =  'SELECT * FROM ps_product WHERE reference='.$original_query.';';
        $result = $DB->executeS($query);
        if(sizeof($result)>0)
        {
            $produit = new Product($result[0]['id_product']);

            header('Location: '.$produit->getLink());
        }
    }
}
?>