<?php class FrontController extends FrontControllerCore
{

    //<title>{if ($seo_title != "")}{$seo_title|escape:'html':'UTF-8'}{else}{$meta_title|escape:'html':'UTF-8'}{/if}</title>
    public function initContent()
    {



        //var_dump($this);
        //echo "<h1>" .  $_GET['controller'] . "</h1>";
        //var_dump($_GET);

        // initialisation par défaut de prestashop
        parent::initContent();
        $bd = mysql_connect ('localhost', 'root', ' ') or die (mysql_error());
        mysql_select_db ('prestashop', $bd)or die (mysql_error());

        if ($_GET['controller'] == 'index')
            $this->context->smarty->assign('seo_title','ACCUEIL SITE MARQUE');

        elseif (($_GET['controller'] == 'product'))
            $this->context->smarty->assign('seo_title','PAGE FICHE PRODUIT AYANT POUR IDENTIFANT ' . $_GET['id_product'] );

        $result = Db::getInstance()->execute("SELECT * FROM seo_rules WHERE controller LIKE '%" .$_GET['controller'] . "%'");


        while ( $donnees = mysql_fetch_array($result)) {
            $nom = $donnees["nom"];
            $titre = $donnees["meta_title"];
            $desc = $donnees ["meta_description"];
        }
        echo "<div class = 'referencement'> <h1> $titre </h1> <p> $desc </p> </div>";
        //var_dump($result);
        //exit;
